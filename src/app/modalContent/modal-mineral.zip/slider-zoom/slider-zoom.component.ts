import { Component, OnInit } from '@angular/core';
import { NavParams, ModalController } from '@ionic/angular';

@Component({
  selector: 'app-slider-zoom',
  templateUrl: './slider-zoom.component.html',
  styleUrls: ['./slider-zoom.component.scss'],
})
export class SliderZoomComponent implements OnInit {
  img:any;
  sliderOpts = {
    zoom: {
      maxRatio :3
    }
  };
  constructor(private navParams: NavParams, private modalController: ModalController) { }

  ngOnInit() {
    this.img = this.navParams.get('img');
  }

  zoom(zoomIn: boolean){

  }
  close(){
    this.modalController.dismiss();
  }
}

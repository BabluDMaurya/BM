# Build *libwebrtc* for cordova-plugin-iosrtc

### Get the *libwebrtc* source code

There are several ways to get and build the library. We choose a project that performs this task nicely:

[react-native-webrtc/blob/master/Documentation/BuildingWebRTC.md](https://github.com/react-native-webrtc/react-native-webrtc/blob/master/Documentation/BuildingWebRTC.md#building-webrtc)


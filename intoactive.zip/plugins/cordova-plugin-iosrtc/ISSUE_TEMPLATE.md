<!--
If you have a question, please ask it in our community: https://groups.google.com/forum/#!forum/cordova-plugin-iosrtc

If you want to report a bug, you are in the right place!

Please include as much information as possible and make the issue title
as descriptive as you can.
-->

#### Expected behavior

#### Observerd behavior

#### Steps to reproduce the problem

#### Platform information

* **Cordova version**:
* **Plugin version**:
* **iOS version**: 
* **Xcode version**:

